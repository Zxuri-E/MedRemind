# MedRemind — Smart Medication Reminder & Routine Organizer

[![Android](https://img.shields.io/badge/Platform-Android%20%7C%20Web-238B78?logo=android&logoColor=white)](#)
[![Capacitor](https://img.shields.io/badge/Runtime-Capacitor%208.6-blue)](#)
[![React](https://img.shields.io/badge/Frontend-React%2018%20%2B%20Vite%205-61DAFB?logo=react&logoColor=black)](#)
[![Node.js](https://img.shields.io/badge/Backend-Express%20%2B%20Node.js-339933?logo=node.js&logoColor=white)](#)
[![Security](https://img.shields.io/badge/Compliance-DPDP%20Act%202023%20%7C%20PBKDF2-success)](#)
[![Tests](https://img.shields.io/badge/Automated%20Tests-52%2F52%20Passing-brightgreen)](#)

MedRemind is an offline-first, enterprise-hardened medication management, adherence tracking, and AI prescription-scanning mobile application. It ensures patients never miss life-critical doses with persistent native Android alarm services that survive application termination, logout, and device restarts.

---

## Key Highlights & Core Capabilities

### 1. Reliable Native Android Alarms (Foreground Service)
- **Lifecycle & Logout Independence**: Ringing alarms **continue to sound even if the user logs out**, switches accounts, clears authentication tokens, closes the app, or locks the screen.
- **Strict 60-Second Ringing Duration**: Alarms automatically stop after exactly 60 seconds without running indefinitely or draining battery.
- **Instant Dismissal**: Dismissing via the on-screen action or persistent notification immediately halts the alarm sound and foreground notification.
- **Idempotency & Duplicate Prevention**: In-memory and persistent `SharedPreferences` state store (`AlarmStateStore`) prevents duplicate triggers within a 60-second window.
- **Boot Recovery**: `MedBootReceiver` reschedules active, non-expired reminders automatically upon device reboot.
- **Daylight Saving & Timezone Resilient**: Calculated using local Android `Calendar` instances rather than naive millisecond math.

### 2. Intelligent Medication Scheduling & Tracking
- **Smart Time Slot Categorizer**: Normalizes any 12-hour, 24-hour, or named time string to standard schedule buckets:
  - **Morning**: `04:00 AM – 11:59 AM`
  - **Afternoon**: `12:00 PM – 04:59 PM`
  - **Evening**: `05:00 PM – 08:59 PM`
  - **Night**: `09:00 PM – 03:59 AM`
- **Dynamic Scheduled Badges**: Custom scheduled timings (e.g. `8:30 AM` or `1:15 PM`) are badged directly on the medicine card.
- **Post-Creation Dosage Timing Editing**:
  - Direct timing adjustment modal (`DosageTimingModal`) accessible via:
    1. **Medicine Detail Screen (`/medicines/:id`)**: One-tap "Edit Timings" button and interactive dose chips.
    2. **Daily Medication Schedule (`/schedule`)**: Direct "Edit Timing" quick action and clickable time pills on any scheduled dose card.
    3. **Add/Edit Medicine Screen (`/medicines/edit/:id`)**: Inline timing chip editing and batch timing editor modal.
  - **Automatic Native Alarm Synchronization**: Modifying any dose time immediately cancels old alarms and reschedules native Android exact alarms and notifications.
  - **Dynamic Frequency & Slot Recalculation**: Automatically updates frequency labels (`Once daily`, `Twice daily`, etc.) and morning/afternoon/night dose counts.
  - **Safe Minimum Dose Validation**: Enforces at least 1 dose timing to prevent empty routines.
- **Multi-Screen Status Synchronization**: Taking, skipping, or undoing a dose updates instantly across the Schedule page, Dashboard, and History analytics.
- **Realistic Adherence Calculation**: Adherence tracking strictly begins from the medication's `startDate`, eliminating phantom past missed doses.

### 3. Official Indian Medicine Database Search
- **250,000+ Verified Pharmaceuticals**: Connected to the comprehensive Indian medicine database with offline in-memory catalog fallback.
- **Relevance-Based Search Ranking**: Prioritizes exact brand matches, prefix matches, and word boundaries. Returns the top 5 most relevant results without cluttering the screen.
- **Commercial Privacy**: Excludes commercial pricing data (`₹` prices are not displayed or stored).

### 4. AI & OCR Prescription Scanner
- **Prescription & Strip Scanning**: Multi-page prescription analysis powered by Gemini AI and Tesseract OCR.
- **Automatic Dosage Parsing**: Recognizes medical shorthand such as `1-0-1`, `1-1-1`, `OD`, `BD`, `TDS`, `QDS`, `HS`, as well as food timings (`AC` / before meals, `PC` / after meals).
- **Patient Verification Alert**: Flags prescriptions whose extracted patient names differ from the logged-in user account.

### 5. Application Security & DPDP Compliance
- **Authentication**: PBKDF2 with SHA-512 password hashing (minimum 6 characters, no arbitrary complexity restrictions).
- **Session Revocation**: Logging out instantly revokes tokens on the backend server.
- **Role-Based Access Control**: Strict separation between Administrator and Patient endpoints. Patients cannot access directory lists or other patient records.
- **Statutory Consent**: Enforces mandatory DPDP Act (2023) consent recording with age confirmation.
- **MIME & Upload Hardening**: Rejects spoofed extensions through file signature verification and limits uploads to 5 files per batch.
- **Android Network Security**: Cleartext HTTP traffic is blocked via `network_security_config.xml` (`usesCleartextTraffic="false"`).

---

## Architecture & Tech Stack

```mermaid
graph TD
    UI["Frontend: React 18 + Vite 5 + Tailwind CSS"]
    Cap["Capacitor 8 Android Bridge"]
    AlarmSvc["Native Android Foreground Service (MedAlarmService)"]
    AlarmMgr["Android AlarmManager (Exact Alarms)"]
    API["Backend: Node.js + Express API"]
    DB["Database: Supabase PostgreSQL (TLS/CA) / SQLite"]
    Store["Local Store: Web Crypto SHA-256 + LocalStorage"]

    UI -->|Capacitor Plugins| Cap
    Cap -->|Native Intents| AlarmSvc
    AlarmSvc -->|Schedules Exact Wakeups| AlarmMgr
    UI -->|REST API / Bearer JWT| API
    API -->|Encrypted TLS| DB
    UI -->|Offline Fallback| Store
```

| Layer | Technologies |
|---|---|
| **Frontend** | React 18, Vite 5, Tailwind CSS, Date-fns, Lucide React, Sonner |
| **Mobile Runtime** | Capacitor 8.6, Android SDK 34/35, Java 21 |
| **Android Native** | `MedAlarmService` (Foreground), `MedAlarmReceiver`, `MedAlarmScheduler`, `MedBootReceiver`, `AlarmStateStore` |
| **Backend API** | Node.js 20+, Express, SQLite (`node:sqlite` / `better-sqlite3`) |
| **Database** | Supabase / PostgreSQL with TLS CA enforcement + local secure JSON fallback |
| **AI / OCR** | Google Gemini API, Tesseract.js, PDF.js |

---

## Project Structure

```text
MedRemind/
├── android/                             # Android native project (Capacitor)
│   ├── app/src/main/
│   │   ├── AndroidManifest.xml          # Permissions, receivers, foreground service
│   │   ├── java/com/medremind/app/      # Native alarm lifecycle implementations
│   │   │   ├── MedAlarmService.java     # 60s foreground alarm playback service
│   │   │   ├── MedAlarmScheduler.java   # AlarmManager exact scheduling & DST safety
│   │   │   ├── MedAlarmReceiver.java    # Broadcast receiver for alarm trigger events
│   │   │   ├── MedBootReceiver.java     # Device reboot alarm recovery
│   │   │   ├── AlarmStateStore.java     # Persistent alarm state & idempotency store
│   │   │   └── MedAlarmPlugin.java      # Capacitor bridge plugin
│   │   └── res/raw/alarm_chime.wav      # Native high-importance alarm audio
├── backend/                             # Express backend & test suites
│   ├── database/                        # PostgreSQL/Supabase & SSL config
│   ├── data/
│   │   ├── indian_medicines.db          # 250,000+ Indian pharmaceuticals SQLite database
│   │   └── medremind_store.json         # Server-side persistent storage
│   ├── server.js                        # Authenticated Express API endpoints
│   ├── test_master_security_and_alarms.js # Automated alarm & security test suite
│   ├── test_schedule_page_slots.js      # Schedule slot mapping verification
│   └── test_indian_medicine_search.js   # Medicine relevance search & price exclusion test
├── src/                                 # React frontend source code
│   ├── components/                      # Common UI cards, badges, buttons, overlays
│   ├── context/
│   │   ├── AuthContext.jsx              # Offline-resilient authentication & PBKDF2
│   │   └── MedicineContext.jsx          # Routine, dose tracking & adherence state
│   ├── pages/
│   │   ├── patient/
│   │   │   ├── DashboardPage.jsx        # Daily routine summary & upcoming dose
│   │   │   ├── SchedulePage.jsx         # Time-slot based daily schedule (Morning, etc.)
│   │   │   ├── AddEditMedicinePage.jsx  # Medicine form with Indian DB search
│   │   │   ├── ScannerPage.jsx          # Prescription & medicine strip scanner
│   │   │   └── HistoryPage.jsx          # Adherence analytics & PDF export
│   │   └── auth/                        # Login & Register pages
│   ├── services/
│   │   ├── alarmService.js              # Web/Native dual-bridge alarm manager
│   │   └── notificationService.js       # Local notifications & time parsers
│   └── utils/
│       ├── scheduleSlotUtils.js         # Slot categorizer & adherence date helpers
│       └── indianMedicineService.js     # Top-5 relevance search (no prices)
├── APK/
│   └── MedRemind-debug.apk              # Ready-to-install Android debug APK
└── MedRemind-Hardened-SourceCode.zip    # Clean source archive
```

---

## Getting Started

### Prerequisites
- **Node.js**: v20.x or v22+
- **JDK**: Java Development Kit 21
- **Android Studio / SDK**: Android SDK Platform 34 or 35 with Build Tools

### 1. Installation

```bash
# Clone or navigate to the repository root
cd MedRemind-Build-SourceCode

# Install root dependencies
npm install

# Install backend dependencies
cd backend && npm install && cd ..
```

### 2. Environment Variables

Create `.env` in the root and in `backend/` using the provided templates:

```bash
cp .env.example .env
cp backend/.env.example backend/.env
```

Ensure `AUTH_SIGNING_SECRET` is configured in `backend/.env` with a secure random key.

### 3. Running the Development Server

```bash
# Start backend API (Port 5000)
node backend/server.js

# In another terminal, start Vite frontend
npm run dev
```

### 4. Building the Android Application

```bash
# 1. Build Vite web assets
npm run build

# 2. Sync web build to Capacitor Android
npx cap sync android

# 3. Compile Android debug APK with Gradle
cd android
./gradlew assembleDebug   # On Windows: .\gradlew.bat assembleDebug
cd ..
```

The compiled APK will be generated at:
```text
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## Automated Verification & Testing

MedRemind includes automated test suites covering native alarm lifecycles, application security, time slot scheduling, and database integrity.

```bash
# Run the complete test suite (52 tests)
npm test

# Run migration security & TLS verification tests
npm run test:security
```

### Test Coverage Summary:
- **Part 1: Alarm Reliability (1.1 – 1.8)**: 60-second auto-stop, explicit dismissal, logout survival, 60s idempotency window, snooze scheduling, DST safety, reboot recovery.
- **Part 2: Security & DPDP Compliance (2.1 – 2.12)**: PBKDF2 authentication, token revocation, RBAC role separation, document protection, consent validation, rate limiting.
- **Part 3: Schedule Page Slot Categorizer (12 tests)**: 12h/24h time mapping, OCR dosage flags, start date boundaries.
- **Part 4: Indian Medicine Relevance Search (3 tests)**: Top-5 result capping, exact brand ranking, price exclusion.
- **Part 5: User-Reported Issues Verification (13 tests)**: Password backward compatibility, strip OCR removal, dynamic calorie bar thresholds, dosage display fixes.
- **Part 6: Dosage Timing Editing Verification (4 tests)**: Post-setup time editing, frequency & dose count recalculation, alarm rescheduling, safe 1-dose minimum validation.
- **Part 7: Multi-Account Medication Isolation (5 tests)**: Strict account-level routine separation, state wiping on logout, fresh account zero-medication guarantee, multi-account switching integrity.

---

## Deliverables

- **Pre-Built Android APK**: [APK/MedRemind-debug.apk](file:///c:/Users/nthar/Desktop/MEDREMIND%20FINAL/MedRemind-Source-and-APK/APK/MedRemind-debug.apk) (32.7 MB).
- **Clean Distributable Source Code**: [MedRemind-Hardened-SourceCode.zip](file:///c:/Users/nthar/Desktop/MEDREMIND%20FINAL/MedRemind-Source-and-APK/MedRemind-Hardened-SourceCode.zip) (58.7 MB, excluding build caches, node_modules, and secrets).
